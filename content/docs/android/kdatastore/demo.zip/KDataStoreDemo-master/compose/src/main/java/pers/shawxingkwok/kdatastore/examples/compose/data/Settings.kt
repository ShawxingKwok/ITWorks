package pers.shawxingkwok.kdatastore.examples.compose.data

import pers.shawxingkwok.kdatastore.KDataStore

object Settings : KDataStore(){
    val isDarkMode by bool(false)

    /* supported types are extensive
    val bool by bool(false)
    val char by char('1')
    val byte by byte(1)
    val short by short(1)
    val int by int(1)
    val long by long(1)
    val float by float(1.0f)
    val double by double(1.0)
    val string by string("1")

    enum class Language{ ENGLISH, GERMAN }
    val enum by enum(Language.ENGLISH)

    @Serializable
    data class Location(val latitude: Double, val longitude: Double)
    val ktSerializable by ktSerializable(Location(38.2, 55.3))

    val javaSerializable by javaSerializable(linkedSetOf(1))

    val any by any(
        default = 1,
        convert = { it.toString() },
        recover = { it.toInt() }
    )
    */
}