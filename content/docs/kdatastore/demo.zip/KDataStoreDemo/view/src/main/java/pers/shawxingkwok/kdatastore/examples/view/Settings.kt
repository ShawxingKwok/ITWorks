package pers.shawxingkwok.kdatastore.examples.view

import pers.shawxingkwok.kdatastore.KDataStore

object Settings : KDataStore(){
    val isDarkMode: Flow<Boolean> by bool(false)
}