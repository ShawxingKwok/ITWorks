package com.example

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import com.example.ui.main.MainFragment
import pers.apollokwok.tracer.common.annotations.Tracer

@Tracer.Root
class MainActivity : AppCompatActivity(), MainActivityTracer {
    val vm: ActivityViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.container, MainFragment.newInstance())
                .commitNow()
        }
    }

    override val _MainActivity: MainActivity get() = this
}