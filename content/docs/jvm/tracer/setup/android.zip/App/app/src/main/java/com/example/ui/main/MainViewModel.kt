package com.example.ui.main

import androidx.lifecycle.ViewModel
import pers.apollokwok.tracer.common.annotations.Tracer

@Tracer.Tip
class MainViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}