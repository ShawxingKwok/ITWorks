package com.example.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.example.MainActivity
import com.example.R
import com.example.`__ActivityViewModel_˚MainActivity_MainActivity_vm`
import pers.apollokwok.tracer.common.annotations.Tracer

@Tracer.Nodes(MainActivity::class)
class MainFragment : Fragment(R.layout.fragment_main), MainFragmentTracer {
    companion object {
        fun newInstance() = MainFragment()
    }

    val vm: MainViewModel by viewModels()

    private val activityVm get() = `__ActivityViewModel_˚MainActivity_MainActivity_vm`



    override val _MainFragment: MainFragment get() = this
}