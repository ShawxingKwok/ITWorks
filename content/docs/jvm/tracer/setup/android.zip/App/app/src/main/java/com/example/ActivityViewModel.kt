package com.example

import androidx.lifecycle.ViewModel
import pers.apollokwok.tracer.common.annotations.Tracer

@Tracer.Tip
class ActivityViewModel : ViewModel() {
}