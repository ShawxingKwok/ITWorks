package com.example

fun main() {
    println("Hello ${MyClass()}!")
}