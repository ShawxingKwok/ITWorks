package com.example

import pers.apollokwok.tracer.common.annotations.Tracer

@Tracer.Root
class MyClass : MyClassTracer{


    override val _MyClass: MyClass get() = this
}